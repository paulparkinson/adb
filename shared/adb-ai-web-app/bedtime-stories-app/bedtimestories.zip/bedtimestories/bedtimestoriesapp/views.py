#this file contains the view functions for handling HTTP request and rendering templates

from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .http_headers import get_access_token, get_common_headers
import requests
import io
import json
from django.conf import settings

#renders home page with text 'Create a bedtime story...'. Checks if the user profile is already selected and redirects to home page.
def home(request):
    if 'userid' in request.session:
        userid = request.session['userid']
        username = request.session['username']
    else:
        userid = request.POST.get('userid')
        username = request.POST.get('username')
    request.session['userid'] = userid
    request.session['username'] = username
    return render(request, "home.html")
    pass

#renders individual story page. Accessed from the left side sliding menu. 
def getMyStory(request):

    # only process auth tokens if API's are secured
    access_token = get_access_token
    
    title = request.POST.get('title')
    id = request.POST.get('id')
    return render(request, 
                  "getmystory.html", 
                  {'title': title, 
                   'id':id,
                   'token':access_token,
                   'apiurl':settings.GET_INDIVIDUAL_STORY})   
    pass    

#renders the write your story page.
def writeStory(request):
    userid = request.session['userid']
    movies = getMovies(userid) #gets the list of movies
    profiles = getProfile(userid) #gets the list of profiles

    return render(request, 
                  "write_story.html", 
                  {'movies': movies,'profiles':profiles})
    pass

#generates the story and displays on the page
def mystory(request):
    access_token = get_access_token()

    #get the list of movies selected by user
    movienames = request.POST.getlist('moviesdata') 
    
    #get the list of profiles selected by user
    characters = request.POST.getlist('charactersdata')
    userid = request.session['userid']
    
    return render(request, 
                  "my_story.html", 
                  {'movienames': movienames,
                   'characters':characters,
                   'user':userid,
                   'token':access_token,
                   'apiurl':settings.CREATE_STORY})   

#renders the left hand sliding navigation
def nav(request):
    
    userid = request.session['userid']
    username = request.session['username']
    stories = getStories(userid)
    return render(request, 
                  "nav.html", 
                  {'stories': stories, 'username':username})

#renders the list of profiles on the homepage
def users(request):
    url = settings.CUSTOMER_PROFILES

    headers = get_common_headers()

    response = requests.request("GET", url, headers=headers)

    users = response.json()
    if 'userid' in request.session:
        del  request.session['userid']
        request.session.save()
    
    return render(request, "users.html", {'users':users['items']})
    pass 

#gets the list of movies for user
def getMovies(user):
    url = settings.GET_MOVIES

    headers = get_common_headers()

    payload = json.dumps({
    "cust_id": user
    })

    response = requests.request("POST", url, headers=headers, data=payload)

    movies = response.json()
    return movies['items'][0]['value']['movies']


#gets the list of profiles for user
def getProfile(user):
    url = settings.CUSTOMER_PROFILES_QUERY

    headers = get_common_headers()

    payload = json.dumps({
    "cust_id": user
    })

    response = requests.request("POST", url, headers=headers, data=payload)

    movies = response.json()
    return movies['items'][0]['value']['profile']    

#get the past stories created for the user. Displayed on left navigation
def getStories(user):
    url = settings.GET_INDIVIDUAL_STORY

    headers = get_common_headers()

    payload = json.dumps({
    "cust_id": user
    })

    response = requests.request("POST", url, headers=headers, data=payload)

    stories = response.json()

    return stories['items']
