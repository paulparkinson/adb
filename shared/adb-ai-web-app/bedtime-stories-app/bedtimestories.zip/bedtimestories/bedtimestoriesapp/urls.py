#This file contains the URL patterns for routing requests to views
from django.urls import path
from . import views
urlpatterns = [
    path('', views.users, name = 'users'),
    path('home/', views.home, name = 'home'),
    path('write-story/', views.writeStory, name = 'write-story'),
    path('my-story/', views.mystory, name = 'my-story'),
    path('get-my-story/', views.getMyStory, name = 'get-my-story'),
]