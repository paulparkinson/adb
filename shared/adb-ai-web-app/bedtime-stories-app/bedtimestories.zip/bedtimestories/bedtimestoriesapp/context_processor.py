from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .http_headers import get_access_token, get_common_headers
import requests
import io
import json
from django.conf import settings


def nav(request):
    stories = []
    if 'userid' in request.session:
        userid = request.session['userid']
        stories = getStories(userid)
    return {'stories': stories}
    

def getStories(user):
    url = settings.GET_INDIVIDUAL_STORY

    payload = json.dumps({
    "cust_id": user
    })

    headers  = get_common_headers()

    response = requests.request("POST", url, headers=headers, data=payload)

    stories = response.json()
    return stories['items'] 

    
    
