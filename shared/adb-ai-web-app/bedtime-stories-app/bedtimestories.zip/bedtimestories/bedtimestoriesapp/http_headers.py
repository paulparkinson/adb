# Generates headers taking into account whether or not OAUTH is enabled
import requests
from django.conf import settings


def get_access_token():
    access_token = ''

    if settings.OAUTH_ENABLED:
        data = {
            'grant_type': 'client_credentials',
        }

        access_token = requests.post(
            settings.OAUTH_TOKEN_URL,
            data=data,
            verify=False,
            auth=(settings.OAUTH_CLIENT_ID, settings.OAUTH_CLIENT_SECRET)).json()["access_token"]
    
    return access_token

def get_common_headers():
    if not settings.OAUTH_ENABLED:
        # insecure
        headers = {
        'Content-Type': 'application/json'
        }
    else:

        access_token = get_access_token(); 

        headers = {
        'Content-Type': 'application/json',
        'Authorization': f'BEARER {access_token}'
        }
    return headers
