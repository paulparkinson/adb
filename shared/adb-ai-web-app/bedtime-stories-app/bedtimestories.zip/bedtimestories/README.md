# Project Name
Bedtime Stories

## Files
#### views.py
Contains the view functions for handling HTTP request and rendering templates
#### urls.py
Contains the URL patterns for routing requests to views
#### settings.py
Contains the configuration settings for the entire application including the Bedtime Stories API configuration

#### static/templates/master.html
Contains the master template including the header and the footer
#### static/templates/nav.html
Contains the HTML for left hand sliding stories navigation 
#### static/templates/users.html
Contains the HTML for the user profile selection
#### static/templates/home.html
Contains the HTML for the create your story landing page
#### static/templates/write_story.html
Contains the HTML for selecting the movies and profiles to creating your story
#### static/templates/my_story.html
Contains the HTML for displaying the story
#### static/templates/getmystory.html
Contains the HTML for fetching individual stories

#### static/splide
Contains the required files for running Splide sliders
#### static/styles.css
Contains the CSS styles used in the application
#### static/images
Contains the images used in the application

## Installation
### **Requirements**

python 3.6
pip3
virtualenv

### **Setup to run**

### Clone the app to your local machine and run the below commands from the folder

#### LINUX


##### Create a virtual environment
python3 -m venv bedtimestories

#####  Activate your virtual environment
source bedtimestories/bin/activate

#####  Install requirements.txt
cd bedtimestories<br>
pip install -r requirements.txt

#####  Propagate changes you make to your models
python3 manage.py makemigrations<br>
python3 manage.py migrate

#####  Run server
python3 manage.py runserver
_________________
#### WINDOWS

#####  Create a virtual environment
python -m venv bedtimestories

#####  Activate your virtual environment
bedtimestories\Scripts\activate

#####  Install requirements.txt
cd bedtimestories<br>
pip install -r requirements.txt

#####  Propagate changes you make to your models
python manage.py makemigrations<br>
python manage.py migrate

#####  Run server
python manage.py runserver
